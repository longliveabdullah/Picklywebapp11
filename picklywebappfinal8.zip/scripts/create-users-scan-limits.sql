-- Create users_scan_limits table for tracking daily scan limits
CREATE TABLE IF NOT EXISTS users_scan_limits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  email VARCHAR(255) NOT NULL,
  scans_today INTEGER DEFAULT 0 CHECK (scans_today >= 0 AND scans_today <= 3),
  last_scan_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_users_scan_limits_user_id ON users_scan_limits(user_id);
CREATE INDEX IF NOT EXISTS idx_users_scan_limits_last_scan_date ON users_scan_limits(last_scan_date);

-- Create trigger for updated_at
CREATE TRIGGER update_users_scan_limits_updated_at 
  BEFORE UPDATE ON users_scan_limits 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security (RLS)
ALTER TABLE users_scan_limits ENABLE ROW LEVEL SECURITY;

-- Create RLS policy
CREATE POLICY "Users can view own scan limits" ON users_scan_limits
  FOR ALL USING (auth.uid() = user_id);
