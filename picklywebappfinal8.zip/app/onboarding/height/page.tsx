"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Ruler, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { OnboardingLayout } from "@/components/onboarding-layout"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/hooks/use-toast"

export default function OnboardingHeightPage() {
  const { user, updateUser } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [height, setHeight] = useState<number | undefined>(user?.profile.height)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!height || height < 50 || height > 250) {
      toast({
        title: "Invalid height",
        description: "Please enter a valid height between 50 and 250 cm",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)
      await updateUser({
        profile: {
          ...user?.profile,
          height,
        },
      })

      setTimeout(() => {
        router.push("/onboarding/weight")
      }, 300)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save your height. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getHeightCategory = (height: number) => {
    if (height < 160) return { label: "Petite", color: "from-pink-400 to-purple-400" }
    if (height < 180) return { label: "Average", color: "from-purple-400 to-blue-400" }
    return { label: "Tall", color: "from-blue-400 to-teal-400" }
  }

  return (
    <OnboardingLayout>
      <div className="space-y-8">
        {/* Header */}
        <motion.div
          className="text-center space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            className="w-16 h-16 bg-gradient-to-r from-pickly-blue to-pickly-teal rounded-full mx-auto flex items-center justify-center mb-4"
            animate={{
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 3,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          >
            <Ruler className="h-8 w-8 text-white" />
          </motion.div>

          <h1 className="text-3xl font-bold bg-gradient-to-r from-pickly-blue via-pickly-teal to-pickly-green bg-clip-text text-transparent">
            What is your height?
          </h1>
          <p className="text-gray-600 font-medium">Enter your height in centimeters</p>
        </motion.div>

        {/* Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className="backdrop-blur-lg bg-white/80 border-0 shadow-xl">
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <motion.div
                  className="space-y-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  <Label htmlFor="height" className="text-lg font-semibold text-gray-700">
                    Height (cm)
                  </Label>
                  <motion.div whileFocus={{ scale: 1.02 }} transition={{ type: "spring", stiffness: 300 }}>
                    <Input
                      id="height"
                      type="number"
                      min={50}
                      max={250}
                      value={height || ""}
                      onChange={(e) => setHeight(e.target.valueAsNumber)}
                      placeholder="Enter your height in cm"
                      className="text-center text-2xl font-bold h-16 border-2 border-gray-200 focus:border-pickly-blue rounded-xl transition-all duration-300"
                      disabled={isLoading}
                    />
                  </motion.div>

                  {/* Height visualization */}
                  {height && height >= 50 && height <= 250 && (
                    <motion.div
                      className="flex items-center justify-center mt-4"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ type: "spring", stiffness: 300 }}
                    >
                      <div className="flex items-end gap-2">
                        <motion.div
                          className={`w-4 bg-gradient-to-t ${getHeightCategory(height).color} rounded-t-full`}
                          style={{ height: `${Math.max(20, (height / 250) * 80)}px` }}
                          animate={{ height: `${Math.max(20, (height / 250) * 80)}px` }}
                          transition={{ type: "spring", stiffness: 300 }}
                        />
                        <span className="text-sm font-medium text-gray-600 mb-1">
                          {getHeightCategory(height).label}
                        </span>
                      </div>
                    </motion.div>
                  )}
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
                  <Button
                    type="submit"
                    className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-pickly-blue via-pickly-teal to-pickly-green hover:from-pickly-teal hover:via-pickly-green hover:to-pickly-blue transition-all duration-300 rounded-xl"
                    disabled={isLoading || !height}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isLoading ? (
                      <motion.div className="flex items-center gap-3" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                        <motion.div
                          className="w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                        />
                        Saving...
                      </motion.div>
                    ) : (
                      <div className="flex items-center gap-3">
                        Continue
                        <motion.div
                          animate={{ x: [0, 5, 0] }}
                          transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
                        >
                          <ArrowRight className="h-5 w-5" />
                        </motion.div>
                      </div>
                    )}
                  </Button>
                </motion.div>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        {/* Height Range Hints */}
        <motion.div
          className="grid grid-cols-3 gap-4 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          {[
            { range: "< 160cm", label: "Petite", color: "from-pink-400 to-purple-400" },
            { range: "160-180cm", label: "Average", color: "from-purple-400 to-blue-400" },
            { range: "> 180cm", label: "Tall", color: "from-blue-400 to-teal-400" },
          ].map((item, index) => (
            <motion.div
              key={item.range}
              className="p-4 bg-white/60 backdrop-blur-sm rounded-xl"
              whileHover={{ scale: 1.05, y: -2 }}
              transition={{ type: "spring", stiffness: 300 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              style={{ animationDelay: `${0.9 + index * 0.1}s` }}
            >
              <div className={`w-8 h-8 bg-gradient-to-r ${item.color} rounded-full mx-auto mb-2`} />
              <p className="text-sm font-semibold text-gray-700">{item.range}</p>
              <p className="text-xs text-gray-500">{item.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </OnboardingLayout>
  )
}
